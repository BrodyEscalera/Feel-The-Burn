<?php $__env->startSection('content'); ?>

    <h1>Create Activity</h1>
    <hr>
    <?php echo Form::open(['url' => 'activities']); ?>


    <?php echo $__env->make('partials.activityForm',['submitButtonText'=>'Add Activity'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



    <?php echo Form::close(); ?>


   <?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>