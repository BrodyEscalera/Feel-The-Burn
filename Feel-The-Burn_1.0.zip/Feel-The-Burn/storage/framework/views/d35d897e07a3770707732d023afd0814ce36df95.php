<?php $__env->startSection('content'); ?>

    <h1>Feed</h1>
    <a href="activities/create">+ Add Activity</a>
    <?php foreach($userActivities as $userActivity): ?>

        <panel>
            <a href="<?php echo e(action('ActivitiesController@show',[$userActivity->id])); ?>"> <ul>
                    <li> <?php echo e($userActivity->activityName); ?></li>
                    <li> <?php echo e($userActivity->distance); ?> mile </li>
                    <li> <?php echo e($userActivity->activity); ?></li>
                    <li> <?php echo e($userActivity->time); ?> minutes</li>

                </ul></a>

        </panel>

    <?php endforeach; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>