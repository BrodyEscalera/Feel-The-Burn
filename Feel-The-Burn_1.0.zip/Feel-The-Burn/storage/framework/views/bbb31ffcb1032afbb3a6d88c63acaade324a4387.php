<?php $__env->startSection('content'); ?>

    <h1> Login</h1>
    <form>
        First name:<br>
        <input type="text" name="firstname"><br>
        Last name:<br>
        <input type="text" name="lastname"><br>
        <input type="submit" value="Submit">
        <!-- Need to access github Authentication using socialite -->

    </form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>