<?php $__env->startSection('content'); ?>

    <h1><?php echo e($activity->activityName); ?></h1>
    <a href="<?php echo e(action('ActivitiesController@edit',[$activity->id])); ?>">edit</a>
    <div id="contentWrapper">

            <panel>
                    <ul>
                        <li> <?php echo e($activity->distance); ?> mile </li>
                        <li> <?php echo e($activity->activity); ?></li>
                        <li> <?php echo e($activity->time); ?> minutes</li>

                    </ul>

            </panel>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>