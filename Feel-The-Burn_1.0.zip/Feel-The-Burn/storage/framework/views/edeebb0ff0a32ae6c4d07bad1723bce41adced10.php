<?php $__env->startSection('content'); ?>

<h1>Profile</h1>
    <div id="contentWrapper">
        <h1></h1>
        <h1><?php echo e($currentWeeklyMiles); ?> total miles for the week</h1>
        <h1><?php echo e($totalTime); ?> Current total time</h1>

        <?php foreach($userActivities as $userActivity): ?>

            <panel>

                    <li> <?php echo e($userActivity->distance); ?> </li>


                </ul></a>

            </panel>

        <?php endforeach; ?>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>