<div class="form-group">
    <?php echo Form::label('activity','Activity'); ?>

    <?php echo Form::select('activity', ['run' => 'run'],'run'); ?>

</div>

<div class="form-group">

    <?php echo Form::label('activityName','Name'); ?>

    <?php echo Form::text('activityName',null,['class'=>'form-control']); ?>

</div>


<div class="form-group">
    <?php echo Form::label('distance','Distance'); ?>

    <?php echo Form::text('distance',null,['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('time','Time'); ?>

    <?php echo Form::text('time',null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::submit($submitButtonText,['class'=>'btn btn-primary form-control']); ?>


</div>