@extends('app')
@section('content')

    <h1> More</h1>
    <div id="contentWrapper">

    </div>

@stop