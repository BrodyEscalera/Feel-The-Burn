@extends('app')
@section('content')
        <div class="container">
            <div class="content">
                <div class="title">Login</div>
            </div>
        </div>
@stop